<?php
header('Content-Type: application/rss+xml; charset=UTF-8');
echo $rss_content=include("silent_feed.php");
?>