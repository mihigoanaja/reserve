<?php
$config=parse_ini_file("config.ini");
function sortPostsByDate(&$posts, $order = 'desc') {
    usort($posts, function ($a, $b) use ($order) {
        $dateA = strtotime($a['date_raw']);
        $dateB = strtotime($b['date_raw']);

        if ($order === 'asc') {
            return $dateA <=> $dateB;
        } else {
            return $dateB <=> $dateA;
        }
    });
}

$rss_content=include("silent_feed.php");
// $rss_url = "https://blog.alreflections.net/feeds/posts/default";
// $xml = simplexml_load_file($rss_url);

$xml = simplexml_load_string($rss_content);

if (!$xml) {
    die("Failed to load RSS feed.");
}

// GET params
$q = isset($_GET['search']) ? strtolower(trim($_GET['search'])) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 60;

// Collect posts
$posts = [];

foreach ($xml->channel->item as $item) {
    $title = (string)$item->title;
    $description = strip_tags((string)$item->description);

    // Search filter
    if ($q) {
        if (
            strpos(strtolower($title), $q) === false &&
            strpos(strtolower($description), $q) === false
        ) {
            continue;
        }
    }

    preg_match('/<img.*?src=["\'](.*?)["\']/', $item->description, $matches);
    $image = $matches[1] ?? "https://placehold.net/default.png";

    $posts[] = [
        "title" => $title,
        "link" => (string)$item->link,
        "description" => $description,
        "date" => date("F j, Y", strtotime($item->pubDate)),
        "date_raw" => (string)$item->pubDate,
        "image" => $image
    ];
}

// Pagination logic
$totalPosts = count($posts);
$totalPages = ceil($totalPosts / $perPage);
$page = max(1, min($page, $totalPages));

$start = ($page - 1) * $perPage;
sortPostsByDate($posts);
$paginatedPosts = array_slice($posts, $start, $perPage);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?=$config["title"]?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>
    <h1><?=$config["title"]?></h1>
    <p><?=$config["tagline"]?></p>

    <!-- 🔎 Search -->
    <form method="GET" class="search-box">
        <input type="text" name="q" placeholder="Search articles..." value="<?= htmlspecialchars($q) ?>">
        <button type="submit">Search</button>
    </form>
</header>

<main class="container">

<?php if (empty($paginatedPosts)): ?>
    <p>No posts found.</p>
<?php endif; ?>

<?php foreach ($paginatedPosts as $post): ?>

    <article class="card">
        <img src="<?= $post['image'] ?>" alt="Post Image">

        <div class="content">
            <h2><?= urldecode($post['title']) ?></h2>
            <p class="date"><?= $post['date'] ?></p>
            <p><?= substr($post['description'], 0, 120) ?>...</p>

            <a href="<?= $post['link'] ?>" target="_blank" class="btn">Read More</a>
        </div>
    </article>

<?php endforeach; ?>

</main>

<!-- 📄 Pagination -->
<div class="pagination">

<?php if ($page > 1): ?>
    <a href="?q=<?= urlencode($q) ?>&page=<?= $page - 1 ?>">← Prev</a>
<?php endif; ?>

<?php
	$start=$page/10;
	$start=(int)$start;
	$start*=10;
	$start+=1;
?>

<?php for ($i = $start; $i <= $totalPages; $i++): ?>
    <a href="?q=<?= urlencode($q) ?>&page=<?= $i ?>" 
       class="<?= ($i == $page) ? 'active' : '' ?>">
       <?= $i ?>
    </a>
	<?php if (($i-$start)==9) break; ?>
<?php endfor; ?>

<?php if ($page < $totalPages): ?>
    <a href="?q=<?= urlencode($q) ?>&page=<?= $page + 1 ?>">Next →</a>
<?php endif; ?>

</div>

<footer>
    <p>© <?= date("Y") ?> <?=$config["copyright_owner"]?></p>
</footer>

</body>
</html>