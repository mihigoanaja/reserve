<?php
function getTextFromHtmlDiv($html) {
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $html = '<div id="root">' . $html . '</div>';
    $dom->loadHTML($html);
    libxml_clear_errors();
    $element = $dom->getElementById('root');
    if ($element) {
        return $element->textContent;
    } else {
        return null;
    }
}

function searchRSSFeed($rssFeed, $searchTerm) {
    $searchResults = [];
    $rssItems = $rssFeed->xpath('//item');
    foreach ($rssItems as $item) {
        $pubdate = (string) $item->pubDate;
        $title = (string) $item->title;
        $description = (string) $item->description;
        if (stripos($title, $searchTerm) !== false || stripos($description, $searchTerm) !== false) {
            $searchResults[] = [
                'title' => $title,
                'description' => $description,
                'link' => (string) $item->link,
                'pubdate' => (string) $pubdate,
            ];
        }
    }
    return $searchResults;
}
$host=$_SERVER['HTTP_HOST'];
//header('Content-Type: application/rss+xml; charset=UTF-8');
    $rssContent='<?xml version="1.0" encoding="UTF-8"?><rss version="2.0" xmlns:atom="https://www.w3.org/2005/Atom"><channel><title>Search Results</title><link>'.$host.'</link><description>Latest updates from Alreflections</description><atom:link href="'.$host.'/feeds/posts/default" rel="self" type="application/rss+xml"/><language>en-us</language><copyright>Copyright 2024</copyright><pubDate>'. date('r'). '</pubDate>';
    $_GET['blogspot']=$_GET['blogspot']??'';
	$_GET['q']=$_GET['q']??'';
	$blogspot =  ($_GET['blogspot']!='')?'https://' . $_GET['blogspot'] . '.blogspot.com/feeds/posts/default':'https://alreflectionsinfo.blogspot.com/feeds/posts/default';
    $rss = $_GET["rss"] ?? $blogspot;

    $rssFeeds = ['https://alreflectionsdc.blogspot.com/feeds/posts/default'
		,'https://alreflectionsdm.blogspot.com/feeds/posts/default'
		,'https://alreflectionsinfo.blogspot.com/feeds/posts/default'
		,'https://alreflectionsdaily.blogspot.com/feeds/posts/default'
	];
	$rssFeeds = explode("\r\n",file_get_contents("feeds.txt"));
	//$rssFeeds []= "https://alreflectionsinfo.blogspot.com/feeds/posts/default";
	if ($blogspot !== 'https://alreflectionsinfo.blogspot.com/feeds/posts/default') {
        $rssFeeds[count($rssFeeds)] = $blogspot;
    }
    //echo end($rssFeeds);
    foreach ($rssFeeds as $rss) {
        $rssFeed = simplexml_load_file($rss . '?max-results=2000&alt=rss&q=' . $_GET['q']);
        $searchTerm = "";
        $searchResults = searchRSSFeed($rssFeed, $searchTerm);
        if (count($searchResults) > 0) {
?>
<?php foreach ($searchResults as $result):
                $rssContent.='<item>';
                    //$rssContent.='<title>'.$result['title'].'</title>';
                    $rssContent.='<pubDate>'.$result['pubdate'].'</pubDate>';
                    $rssContent.='<title>'.urlencode($result['title']).'</title>';
                    $rssContent.='<link>'.htmlspecialchars($result['link']).'</link>';
                    //$rssContent.='<link>'."https://atinas.alreflections.net/sitemap/blogload.php?u=" . $result['link'].'</link>';
                    $rssContent.='<description>';
                        //$description = htmlspecialchars($result['description']);
                        $description = "<![CDATA[".$result['description']."]]>";
                        $rssContent.=$description;
                    $rssContent.='</description>';
                    $rssContent.= '<guid isPermaLink="true">'. htmlspecialchars($result['link']). '</guid>';
                    $rssContent.='</item>';
                // echo $rss;
                endforeach;
?>
<?php
        }
        if ($rssFeeds[count($rssFeeds)-1]==$rss) {
            $rssContent=str_replace('\t','',$rssContent);
            $rssContent=str_replace('\n','',$rssContent);
            $rssContent=str_replace('  ','',$rssContent);
            $rssContent=preg_replace('/\n/','',$rssContent);
            $rssContent=preg_replace('/\t/','',$rssContent);
            $rssContent=preg_replace('/( )+/',' ',$rssContent);
            $rssContent.="</channel></rss>";
        };
    }
	return $rssContent;
?>