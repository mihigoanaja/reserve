<?php

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'infocratiz');

$documentRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : null;
$projectRoot = realpath(__DIR__);
$basePath = '';

if ($documentRoot && $projectRoot) {
    $documentRoot = str_replace('\\', '/', $documentRoot);
    $projectRoot = str_replace('\\', '/', $projectRoot);

    if (strpos($projectRoot, $documentRoot) === 0) {
        $basePath = substr($projectRoot, strlen($documentRoot));
    }
}

$basePath = trim(str_replace('\\', '/', $basePath), '/');

define('SITE_NAME', 'Infocratiz');
define('APP_BASE_PATH', $basePath !== '' ? '/' . $basePath : '');
define('DEFAULT_THUMBNAIL', APP_BASE_PATH . '/assets/default-thumb.svg');
define('OFFERS_PER_PAGE', 20);
define('HOME_CATEGORY_LIMIT', 4);
define('STALE_DAYS', 30);
define('STALE_REFRESH_CHANCE', 35);
