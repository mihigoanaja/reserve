<?php

require_once __DIR__ . '/../includes/helpers.php';

if (is_logged_in()) {
    redirect_to('dashboard/');
}

$setupMode = !users_exist();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($setupMode) {
        $name = trim((string) ($_POST['name'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
            $error = 'Enter a valid name, email, and a password with at least 8 characters.';
        } else {
            $result = create_initial_admin($name, $email, $password);
            if ($result['ok']) {
                redirect_to('dashboard/');
            }
            $error = $result['error'];
        }
    } else {
        $email = trim((string) ($_POST['email'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $result = authenticate_user($email, $password);

        if ($result['ok']) {
            redirect_to('dashboard/');
        }

        $error = $result['error'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($setupMode ? 'Create Admin' : 'Admin Login'); ?> | <?php echo e(SITE_NAME); ?></title>
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="<?php echo e(app_url('assets/styles.css')); ?>">
</head>
<body class="dashboard-body">
    <main class="container" style="max-width: 560px; padding: 48px 0;">
        <section class="panel">
            <h1><?php echo e($setupMode ? 'Create the admin account' : 'Admin login'); ?></h1>
            <p>
                <?php echo e($setupMode
                    ? 'Only the first account can be created. That account becomes the admin and unlocks the dashboard.'
                    : 'Registration is closed. Sign in with the admin account to open the dashboard.'); ?>
            </p>

            <?php if ($error !== ''): ?>
                <div class="flash flash-error"><?php echo e($error); ?></div>
            <?php endif; ?>

            <form method="post" action="<?php echo e(app_url('dashboard/login.php')); ?>">
                <?php if ($setupMode): ?>
                    <label>Full name</label>
                    <input type="text" name="name" required>
                <?php endif; ?>

                <label>Email</label>
                <input type="email" name="email" required>

                <label>Password</label>
                <input type="password" name="password" required minlength="8">

                <button type="submit"><?php echo e($setupMode ? 'Create admin account' : 'Login'); ?></button>
            </form>
        </section>
    </main>
</body>
</html>
