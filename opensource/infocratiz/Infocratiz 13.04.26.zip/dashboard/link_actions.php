<?php

require_once __DIR__ . '/../includes/helpers.php';

require_admin_auth();

$returnTo = isset($_POST['return_to']) && $_POST['return_to'] === 'links' ? 'dashboard/links.php' : 'dashboard/';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_to($returnTo);
}

$action = isset($_POST['action']) ? trim((string) $_POST['action']) : '';

if ($action === 'create') {
    $categoryId = (int) ($_POST['category_id'] ?? 0);
    $url = trim((string) ($_POST['url'] ?? ''));
    $hasExpiry = isset($_POST['has_expiry']) && $_POST['has_expiry'] === '1';
    $expiresAt = $hasExpiry ? trim((string) ($_POST['expires_at'] ?? '')) : null;
    $expiresAt = $expiresAt !== '' ? $expiresAt : null;

    if ($categoryId > 0 && $url !== '') {
        $saved = create_opportunity($categoryId, $url, $expiresAt);
        $status = $saved['ok'] ? 'Opportunity saved' : $saved['error'];
        redirect_to($returnTo . '?status=' . urlencode($status));
    }

    redirect_to($returnTo . '?status=Missing category or URL');
}

if ($action === 'bulk_create') {
    $categoryId = (int) ($_POST['category_id'] ?? 0);
    $urls = trim((string) ($_POST['urls'] ?? ''));
    $hasExpiry = isset($_POST['has_expiry']) && $_POST['has_expiry'] === '1';
    $expiresAt = $hasExpiry ? trim((string) ($_POST['expires_at'] ?? '')) : null;
    $expiresAt = $expiresAt !== '' ? $expiresAt : null;

    if ($categoryId > 0 && $urls !== '') {
        $result = create_opportunities_bulk($categoryId, $urls, $expiresAt);
        $status = $result['saved'] . ' link(s) saved';

        if ($result['failed'] > 0) {
            $status .= ', ' . $result['failed'] . ' failed';
        }

        redirect_to($returnTo . '?status=' . urlencode($status));
    }

    redirect_to($returnTo . '?status=Missing category or URLs');
}

if ($action === 'delete') {
    $id = (int) ($_POST['id'] ?? 0);

    if ($id > 0) {
        delete_opportunity($id);
    }

    redirect_to($returnTo . '?status=Opportunity removed');
}

redirect_to($returnTo);
