<?php

require_once __DIR__ . '/../includes/helpers.php';

require_admin_auth();

$user = current_user();
$categories = get_categories();
$flash = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories | <?php echo e(SITE_NAME); ?></title>
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="<?php echo e(app_url('assets/styles.css')); ?>">
</head>
<body class="dashboard-body">
    <main class="container dashboard-layout">
        <aside class="dashboard-aside">
            <h1>Categories</h1>
            <p>Create and organize opportunity groups here.</p>
            <p>Signed in as <?php echo e($user['name']); ?>.</p>
            <a class="section-link" href="<?php echo e(app_url('dashboard/')); ?>">Back to dashboard</a>
            <a class="section-link" href="<?php echo e(app_url('dashboard/links.php')); ?>">Manage links</a>
        </aside>

        <section class="dashboard-main">
            <?php if ($flash !== ''): ?>
                <div class="flash"><?php echo e($flash); ?></div>
            <?php endif; ?>

            <section class="panel">
                <h2>Add category</h2>
                <form method="post" action="<?php echo e(app_url('dashboard/category_actions.php')); ?>">
                    <input type="hidden" name="action" value="create">
                    <input type="hidden" name="return_to" value="categories">
                    <label>Name</label>
                    <input type="text" name="name" required>
                    <label>Description</label>
                    <textarea name="description" rows="3" placeholder="Short category description"></textarea>
                    <button type="submit">Save category</button>
                </form>
            </section>

            <section class="panel">
                <h2>All categories</h2>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td><?php echo e($category['name']); ?></td>
                                    <td><?php echo e($category['description']); ?></td>
                                    <td>
                                        <form class="inline-form" method="post" action="<?php echo e(app_url('dashboard/category_actions.php')); ?>">
                                            <input type="hidden" name="action" value="update">
                                            <input type="hidden" name="return_to" value="categories">
                                            <input type="hidden" name="id" value="<?php echo e($category['id']); ?>">
                                            <input type="text" name="name" value="<?php echo e($category['name']); ?>" required>
                                            <input type="text" name="description" value="<?php echo e($category['description']); ?>">
                                            <button type="submit">Edit</button>
                                        </form>
                                        <form class="inline-form danger-form" method="post" action="<?php echo e(app_url('dashboard/category_actions.php')); ?>" onsubmit="return confirm('Delete this category and its links?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="return_to" value="categories">
                                            <input type="hidden" name="id" value="<?php echo e($category['id']); ?>">
                                            <button type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </section>
    </main>
</body>
</html>
