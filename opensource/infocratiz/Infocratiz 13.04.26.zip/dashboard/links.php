<?php

require_once __DIR__ . '/../includes/helpers.php';

require_admin_auth();

$user = current_user();
$categories = get_categories();
$opportunities = get_dashboard_opportunities();
$topCategory = get_category_with_most_links();
$preferredCategoryId = $topCategory ? (int) $topCategory['id'] : 0;
$flash = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Links | <?php echo e(SITE_NAME); ?></title>
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="<?php echo e(app_url('assets/styles.css')); ?>">
</head>
<body class="dashboard-body">
    <main class="container dashboard-layout">
        <aside class="dashboard-aside">
            <h1>Links</h1>
            <p>Add single or bulk opportunity URLs and review saved previews.</p>
            <p>Signed in as <?php echo e($user['name']); ?>.</p>
            <a class="section-link" href="<?php echo e(app_url('dashboard/')); ?>">Back to dashboard</a>
            <a class="section-link" href="<?php echo e(app_url('dashboard/categories.php')); ?>">Manage categories</a>
        </aside>

        <section class="dashboard-main">
            <?php if ($flash !== ''): ?>
                <div class="flash"><?php echo e($flash); ?></div>
            <?php endif; ?>

            <div class="dashboard-grid">
                <section class="panel">
                    <h2>Add one link</h2>
                    <form method="post" action="<?php echo e(app_url('dashboard/link_actions.php')); ?>">
                        <input type="hidden" name="action" value="create">
                        <input type="hidden" name="return_to" value="links">
                        <label>Category</label>
                        <select name="category_id" required>
                            <option value="">Choose a category</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo e($category['id']); ?>" <?php echo $preferredCategoryId === (int) $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo e($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <label>Opportunity URL</label>
                        <input type="url" name="url" required placeholder="https://example.com/offer">
                        <label class="checkbox-row">
                            <input type="checkbox" name="has_expiry" value="1" data-toggle-expiry>
                            <span>This link expires on a specific date</span>
                        </label>
                        <input type="date" name="expires_at" data-expiry-input disabled>
                        <button type="submit">Preview and save link</button>
                    </form>
                </section>

                <section class="panel">
                    <h2>Bulk insert links</h2>
                    <form method="post" action="<?php echo e(app_url('dashboard/link_actions.php')); ?>">
                        <input type="hidden" name="action" value="bulk_create">
                        <input type="hidden" name="return_to" value="links">
                        <label>Category</label>
                        <select name="category_id" required>
                            <option value="">Choose a category</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo e($category['id']); ?>" <?php echo $preferredCategoryId === (int) $category['id'] ? 'selected' : ''; ?>>
                                    <?php echo e($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <label>One URL per line</label>
                        <textarea name="urls" rows="10" placeholder="https://example.com/offer-1&#10;https://example.com/offer-2" required></textarea>
                        <label class="checkbox-row">
                            <input type="checkbox" name="has_expiry" value="1" data-toggle-expiry>
                            <span>All these links expire on a specific date</span>
                        </label>
                        <input type="date" name="expires_at" data-expiry-input disabled>
                        <button type="submit">Preview and save all valid links</button>
                    </form>
                </section>
            </div>

            <section class="panel">
                <h2>Saved opportunities</h2>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Preview</th>
                                <th>Category</th>
                                <th>Expires</th>
                                <th>Last previewed</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($opportunities as $item): ?>
                                <tr>
                                    <td>
                                        <div class="mini-offer">
                                            <img src="<?php echo e($item['thumbnail'] ?: DEFAULT_THUMBNAIL); ?>" alt="<?php echo e($item['title']); ?>">
                                            <div>
                                                <strong><?php echo e($item['title']); ?></strong>
                                                <p><?php echo e($item['description']); ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($item['category_name']); ?></td>
                                    <td><?php echo e($item['expires_at'] ?: 'No expiry'); ?></td>
                                    <td><?php echo e($item['last_previewed_at'] ?: 'Never'); ?></td>
                                    <td>
                                        <form class="inline-form danger-form" method="post" action="<?php echo e(app_url('dashboard/link_actions.php')); ?>" onsubmit="return confirm('Remove this link?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="return_to" value="links">
                                            <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                                            <button type="submit">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </section>
    </main>

    <script src="<?php echo e(app_url('assets/app.js')); ?>"></script>
</body>
</html>
