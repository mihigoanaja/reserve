<?php

require_once __DIR__ . '/../includes/helpers.php';

logout_user();
redirect_to('dashboard/login.php');
