<?php

require_once __DIR__ . '/../includes/helpers.php';

require_admin_auth();

$returnTo = isset($_POST['return_to']) && $_POST['return_to'] === 'categories' ? 'dashboard/categories.php' : 'dashboard/';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_to($returnTo);
}

$action = isset($_POST['action']) ? trim((string) $_POST['action']) : '';

if ($action === 'create') {
    $name = trim((string) ($_POST['name'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));

    if ($name !== '') {
        create_category($name, $description);
    }

    redirect_to($returnTo . '?status=Category saved');
}

if ($action === 'update') {
    $id = (int) ($_POST['id'] ?? 0);
    $name = trim((string) ($_POST['name'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));

    if ($id > 0 && $name !== '') {
        update_category($id, $name, $description);
    }

    redirect_to($returnTo . '?status=Category updated');
}

if ($action === 'delete') {
    $id = (int) ($_POST['id'] ?? 0);

    if ($id > 0) {
        delete_category($id);
    }

    redirect_to($returnTo . '?status=Category deleted');
}

redirect_to($returnTo);
