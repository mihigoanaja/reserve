CREATE DATABASE IF NOT EXISTS infocratiz CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE infocratiz;

CREATE TABLE IF NOT EXISTS categories (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    slug VARCHAR(150) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(30) NOT NULL DEFAULT 'admin',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS opportunities (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    category_id INT UNSIGNED NOT NULL,
    url VARCHAR(2048) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    thumbnail VARCHAR(2048) DEFAULT NULL,
    expires_at DATE DEFAULT NULL,
    last_previewed_at DATETIME DEFAULT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_opportunities_category
        FOREIGN KEY (category_id) REFERENCES categories(id)
        ON DELETE CASCADE
);

INSERT INTO categories (name, slug, description, created_at, updated_at)
SELECT * FROM (
    SELECT 'Affiliate Links', 'affiliate-links', 'Special offers, programs and revenue opportunities.', NOW(), NOW()
) AS tmp
WHERE NOT EXISTS (
    SELECT 1 FROM categories WHERE slug = 'affiliate-links'
)
LIMIT 1;

INSERT INTO categories (name, slug, description, created_at, updated_at)
SELECT * FROM (
    SELECT 'Jobs', 'jobs', 'Career openings, remote jobs and paid work.', NOW(), NOW()
) AS tmp
WHERE NOT EXISTS (
    SELECT 1 FROM categories WHERE slug = 'jobs'
)
LIMIT 1;

INSERT INTO categories (name, slug, description, created_at, updated_at)
SELECT * FROM (
    SELECT 'Scholarships', 'scholarships', 'Funding opportunities, grants and student support.', NOW(), NOW()
) AS tmp
WHERE NOT EXISTS (
    SELECT 1 FROM categories WHERE slug = 'scholarships'
)
LIMIT 1;

INSERT INTO categories (name, slug, description, created_at, updated_at)
SELECT * FROM (
    SELECT 'Bonuses', 'bonuses', 'Promotions, claims and welcome bonuses.', NOW(), NOW()
) AS tmp
WHERE NOT EXISTS (
    SELECT 1 FROM categories WHERE slug = 'bonuses'
)
LIMIT 1;
