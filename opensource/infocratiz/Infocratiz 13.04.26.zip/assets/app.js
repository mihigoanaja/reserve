document.addEventListener('DOMContentLoaded', function () {
    var toggles = document.querySelectorAll('[data-toggle-expiry]');

    toggles.forEach(function (toggle) {
        var form = toggle.closest('form');
        var input = form ? form.querySelector('[data-expiry-input]') : null;

        if (!input) {
            return;
        }

        var syncState = function () {
            input.disabled = !toggle.checked;
            if (!toggle.checked) {
                input.value = '';
            }
        };

        toggle.addEventListener('change', syncState);
        syncState();
    });
});
