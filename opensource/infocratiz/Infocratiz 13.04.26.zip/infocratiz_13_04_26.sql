SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

CREATE DATABASE IF NOT EXISTS infocratiz DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE infocratiz;

CREATE TABLE IF NOT EXISTS categories (
  id int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  name varchar(120) NOT NULL,
  slug varchar(150) NOT NULL,
  description varchar(255) DEFAULT NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY slug (slug)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO categories (id, name, slug, description, created_at, updated_at) VALUES
(1, 'Freebies', 'freebies', 'Special offers, programs and revenue opportunities.', '2026-04-13 13:04:02', '2026-04-13 13:12:19'),
(2, 'Jobs', 'jobs-', 'Career openings, remote jobs and paid work.', '2026-04-13 13:05:16', '2026-04-13 13:05:16'),
(3, 'Scholarships', 'scholarships-', 'Funding opportunities, grants and student support.', '2026-04-13 13:05:16', '2026-04-13 13:05:16'),
(4, 'Bonuses', 'bonuses-', 'Promotions, claims and welcome bonuses.', '2026-04-13 13:05:16', '2026-04-13 13:05:16');

CREATE TABLE IF NOT EXISTS opportunities (
  id int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id int(10) UNSIGNED NOT NULL,
  url varchar(2048) NOT NULL,
  title varchar(255) NOT NULL,
  description text DEFAULT NULL,
  thumbnail varchar(2048) DEFAULT NULL,
  expires_at date DEFAULT NULL,
  last_previewed_at datetime DEFAULT NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY (id),
  KEY fk_opportunities_category (category_id)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO opportunities (id, category_id, url, title, description, thumbnail, expires_at, last_previewed_at, created_at, updated_at) VALUES
(1, 1, 'https://platform.shoffi.app/r/rl_MhfXv96X', 'Adwisely Google Ads & Meta Ads - AI Google Ads, Meta Ads & Facebook Ads — managed... | Shopify App Store', 'AI-powered Google Ads, Meta Ads, Facebook Ads & Instagram Ads for Shopify. Launch smart retargeting & prospecting campaigns. Expert support to maximize ROAS', 'https://cdn.shopify.com/app-store/listing_images/721aa292ef35d837a88200d85d27dbb6/icon/CMv8_5rIiY0DEAE=.png', NULL, '2026-04-13 13:13:40', '2026-04-13 13:13:40', '2026-04-13 13:13:40'),
(2, 1, 'https://platform.shoffi.app/r/rl_MVLPKX2v', 'Evey Events & Tickets - Effortlessly schedule, scan, and sell tickets with a calendar | Shopify App Store', 'The All-You-Need event toolkit to help make your event a success. From your first ticket sale, merch sales, and check-in at the door.', 'https://cdn.shopify.com/app-store/listing_images/500e84e2ba872181214f4a627ede97d7/icon/CPmv4d70lu8CEAE=.jpg', NULL, '2026-04-13 13:14:18', '2026-04-13 13:14:18', '2026-04-13 13:14:18'),
(3, 1, 'https://platform.shoffi.app/r/rl_2atYtPcK', 'Kiwi Size Chart & Recommender - Create customizable size charts that convert + reduce returns | Shopify App Store', 'Kiwi helps increase sales and lower returns with size recommendation systems and size charts.', 'https://cdn.shopify.com/app-store/listing_images/d3885e152c3d7c1a0526f5f916b5d61e/icon/CJDcxMP0lu8CEAE=.png', NULL, '2026-04-13 13:15:19', '2026-04-13 13:15:19', '2026-04-13 13:15:19'),
(4, 1, 'https://platform.shoffi.app/r/rl_8RJgts94', 'Trackr: Order Tracking UpSell - Order Tracker: track orders with branded tracking page. | Shopify App Store', 'Trackr is an order tracking app that creates branded custom tracking pages, reduces WISMO inquiries, and keeps customers updated automatically.', 'https://cdn.shopify.com/app-store/listing_images/8576ccd5d856648882f233bc7fc4951e/icon/COjZrMP3rosDEAE=.png', NULL, '2026-04-13 13:18:23', '2026-04-13 13:18:23', '2026-04-13 13:18:23'),
(5, 1, 'https://platform.shoffi.app/r/rl_dvA0uo2J', 'Assortion: Upsell & Bundles - Create product bundles, volume discount, and upsell offers | Shopify App Store', 'Assortion is a one-stop-shop for all your upsell and cross-sell needs. Instead of using 5 different apps with separate integration, analytics, lear...', 'https://cdn.shopify.com/app-store/listing_images/0df3ce6f1fb8aadee20334bfd8cf0d3c/icon/CI-Ut6PL8_4CEAE=.jpeg', NULL, '2026-04-13 13:22:08', '2026-04-13 13:22:08', '2026-04-13 13:22:08'),
(6, 1, 'https://platform.shoffi.app/r/rl_sRzYYbe4', 'Disputifier: Smart Chargebacks - Prevent and fight chargebacks on autopilot | Shopify App Store', 'Fully automated chargeback fighting and chargeback prevention. Effortlessly win more disputes and help stop fraudulent chargebacks & disputes.', 'https://cdn.shopify.com/app-store/listing_images/963739f30cd85f6491a28a7a690e9e16/icon/CLnP49bZnoMDEAE=.png', NULL, '2026-04-13 13:23:09', '2026-04-13 13:23:09', '2026-04-13 13:23:09'),
(7, 1, 'https://platform.shoffi.app/r/rl_ZsJYuT4R', 'Dripshipper: Coffee & Tea - Dropship private label coffee and tea with your branding. | Shopify App Store', 'We dropship private label coffee and tea to your customers. Our coffee, your brand. When a customer visits your site and orders coffee, Dripshipper...', 'https://cdn.shopify.com/app-store/listing_images/4d0c89e6590f4e3ba67f4ff6a66ac3a9/icon/CIKflsj0lu8CEAE=.jpg', NULL, '2026-04-13 13:23:32', '2026-04-13 13:23:32', '2026-04-13 13:23:32'),
(8, 1, 'https://platform.shoffi.app/r/rl_wpmkaUHb', 'ShipProtect ShippingProtection - Sell shipping protection to increase trust and recover costs | Shopify App Store', 'Charge a % of Shopify cart value as shipping protection to increase revenue and customer peace of mind.', 'https://cdn.shopify.com/app-store/listing_images/8641704f8b4d2eb3be8f0bdc26160763/icon/CO73qIqlnokDEAE=.png', NULL, '2026-04-13 13:24:02', '2026-04-13 13:24:02', '2026-04-13 13:24:02'),
(9, 1, 'https://platform.shoffi.app/r/rl_d2wACXMg', 'MigrationPro: Store Migration - Import & migrate your full store data in bulk —... | Shopify App Store', 'Migrate your store to Shopify with zero downtime. Securely transfer products, customers, and orders while preserving SEO. A trusted store importer for Shopify!', 'https://cdn.shopify.com/app-store/listing_images/3996cd749f231811230f0ca74cb186b1/icon/CI_E7dHMjpIDEAE=.png', NULL, '2026-04-13 13:24:37', '2026-04-13 13:24:37', '2026-04-13 13:24:37'),
(10, 1, 'https://platform.shoffi.app/r/rl_4gZr04ea', 'Storista Shoppable Videos UGC - Add social proof with shoppable video sections and UGC | Shopify App Store', 'Turn TikTok, Reels & UGC into shoppable videos. Add carousels, stories & galleries anywhere on Shopify. Fast & SEO-friendly with analytics to prove ROI.', 'https://cdn.shopify.com/app-store/listing_images/7bc98c82d4d6fddcb7eb945ae75f58f9/icon/CIus4v6SzYwDEAE=.png', NULL, '2026-04-13 13:25:08', '2026-04-13 13:25:08', '2026-04-13 13:25:08'),
(11, 1, 'https://platform.shoffi.app/r/rl_cgKm4Mg5', 'Tapita AI SEO Optimizer, Speed - Boost traffic & sales with SEO booster, AI SEO image... | Shopify App Store', 'One-click optimize SEO & page speed for both Google and customers for better conversion and sales.', 'https://cdn.shopify.com/app-store/listing_images/98174eb34c15877a277f4e0fde830a20/icon/CPf3hu-TqP0CEAE=.jpeg', NULL, '2026-04-13 13:26:54', '2026-04-13 13:26:54', '2026-04-13 13:26:54'),
(12, 1, 'https://platform.shoffi.app/r/rl_Lacwj3Wa', 'Deposit & Partial Payment Depo - Manage deposits, preorder, partial payments, and split payment | Shopify App Store', 'Partial payment split payment, pre-order, and deposit management app that allows you to seamlessly take deposits on your store', 'https://cdn.shopify.com/app-store/listing_images/09fd0c97fbb441a897fdc08b3f77ffc4/icon/CMu1-_ajg4QDEAE=.jpeg', NULL, '2026-04-13 13:29:04', '2026-04-13 13:29:04', '2026-04-13 13:29:04'),
(13, 1, 'https://platform.shoffi.app/r/rl_lOWR0BBy', 'Easy Lottie Animations - Add Lottie Animations To Your Store Easily! | Shopify App Store', 'Add Lottie animations to your store in a few clicks, and bring your store to life!', 'https://cdn.shopify.com/app-store/listing_images/8ac27fc201f9864713bf46b09b6d0c0e/icon/CJrs_8fAnfECEAE=.png', NULL, '2026-04-13 13:29:06', '2026-04-13 13:29:06', '2026-04-13 13:29:06'),
(14, 1, 'https://platform.shoffi.app/r/rl_9WWaoZ0e', 'Appointment Booking App ointo - Booking app to take appointments and bookings on your calendar | Shopify App Store', 'Appointment Booking app lets you take bookings and appointments directly from your Shopify website. Connect your calendar and setup your services in 2 minutes.', 'https://cdn.shopify.com/app-store/listing_images/b3dccf14643e2c76121cb5c5ca9a068e/icon/CLiykKz0lu8CEAE=.png', NULL, '2026-04-13 13:29:11', '2026-04-13 13:29:11', '2026-04-13 13:29:11'),
(15, 1, 'https://platform.shoffi.app/r/rl_nKo8ohjH', 'G: Combined Listings & Variant - Group products, customize product variant image & color swatch | Shopify App Store', 'Grouptify assists Shopify merchants in merging related products into a single display, enhancing conversions and the overall shopping experience. Swatches, SEO', 'https://cdn.shopify.com/app-store/listing_images/f3c7e2f5de24101b794516ae2211c449/icon/CPbO6JXT84gDEAE=.png', NULL, '2026-04-13 13:29:13', '2026-04-13 13:29:13', '2026-04-13 13:29:13'),
(16, 1, 'https://platform.shoffi.app/r/rl_ittLumj8', 'Essential Free Shipping Upsell - Lift AOV via Free Shipping Bar Goal Cart Upsell and... | Shopify App Store', 'Essential Free Shipping Bar boosts sales and AOV by displaying a free shipping progress bar and upsells on your cart page. Download now and increase your sales!', 'https://cdn.shopify.com/app-store/listing_images/fc98dbd23e8e139349b2426307effd9e/icon/CLnelfCP_fcCEAE=.png', NULL, '2026-04-13 13:29:15', '2026-04-13 13:29:15', '2026-04-13 13:29:15'),
(17, 1, 'https://platform.shoffi.app/r/rl_SyEzgeFv', 'LangShop AI Language Translate - Translate language with Open AI, DeepL and convert currency. | Shopify App Store', 'Translate language & convert currency of your Shopify Store in minutes to drive more sales with essential Shopify app.', 'https://cdn.shopify.com/app-store/listing_images/36881f6a4f1818cb5cffe1d6cf5cb302/icon/COj5_M_wwIIDEAE=.png', NULL, '2026-04-13 13:29:18', '2026-04-13 13:29:18', '2026-04-13 13:29:18'),
(18, 1, 'https://platform.shoffi.app/r/rl_tPEVat9t', 'Panda Bundles Volume Discounts - Setup quantity breaks, bundles, BOGO, discounts upsells & more | Shopify App Store', 'Create bundles and discounts that not only helps AOV but also drive higher conversion rates for shopify stores. Increase your AOV through our app', 'https://cdn.shopify.com/app-store/listing_images/10ef4f9cc9f59597a4f3889cfbade1ed/icon/CP-_8Zf_44sDEAE=.png', NULL, '2026-04-13 13:29:21', '2026-04-13 13:29:21', '2026-04-13 13:29:21'),
(19, 1, 'https://platform.shoffi.app/r/rl_9aDQ2jTi', 'Upsell & Cross Sell — Selleasy - Frequently bought together bundles & in cart upsell, boost AOV | Shopify App Store', 'Frequently bought together bundles, one click upsell & cross sell for Shopify. In cart upsell, checkout upsell, post purchase offers & product recommendations.', 'https://cdn.shopify.com/app-store/listing_images/50d1becb99d333549c4316fc695bc00e/icon/CJGWisGV0oADEAE=.png', NULL, '2026-04-13 13:39:16', '2026-04-13 13:39:16', '2026-04-13 13:39:16'),
(20, 1, 'https://platform.shoffi.app/r/rl_NZ22NOAw', 'ShipX ‑ Shipping Rates & Rules - Shipping calculator with custom shipping rules & pickup points | Shopify App Store', 'Set custom shipping rules & rates by product, weight, postcode, zip code & distance. Shipping rate calculator with rate blending, AI packaging & shipping zones.', 'https://cdn.shopify.com/app-store/listing_images/ff434226b7f91094b637c1285b845417/icon/CJfH452A1IADEAE=.png', NULL, '2026-04-13 13:39:19', '2026-04-13 13:39:19', '2026-04-13 13:39:19'),
(21, 1, 'https://platform.shoffi.app/r/rl_mYIA5L0v', 'Fantastic Markets Discounts - Create exclusive and automatic discounts for every market. | Shopify App Store', 'Fantastic Markets discounts is the first app that allows you to create and schedule exclusive offers for each of your Shopify Markets.', 'https://cdn.shopify.com/app-store/listing_images/a0b07db1e83a7cd4e7c45dbc21a2e066/icon/CJSQk9XirIADEAE=.png', NULL, '2026-04-13 13:39:21', '2026-04-13 13:39:21', '2026-04-13 13:39:21'),
(24, 4, 'https://www.alreflections.net/2026/01/are-you-looking-for-professional.html', 'Are You Looking For A Professional Website? Our Service Come With Free Promotion As A Bonus', 'Alreflections is a dynamic software company expanding globally, offers a range of marketing solutions for your business needs.', 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjQ4Wi35JpWXlWfQR26-egIQu25Wpa0YcWA9s3-qqaj1YHcujtvQFLYZ5KoYQDLKr2HQqfgKBq8tWRVrbpO9COL50p14s3oagGpKFD7izwf7GxVcspSYJ2PfKWb9apmhZHa858MfAB1Pf9Az7P5a-nnwGzqDPirZyYP4_Dx2bHvnZZyXFfsopHzGJLT4ik/s1600/Tunga%20Website%20Promo.jpg', NULL, '2026-04-13 13:57:50', '2026-04-13 13:57:50', '2026-04-13 13:57:50'),
(26, 4, 'https://www.alreflections.net/2024/12/alreflections-startup-support.html', 'Alreflections Startup Support', 'Alreflections is a dynamic software company expanding globally, offers a range of marketing solutions for your business needs.', 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjJg2uEnRv8gqrTJ9rBKhyl3MNPabYYXPfpuIWFxuV66h0a7ZHLN1rZDRV28Q7V8eBmKoPLN4MD6yuUD7Xh4EDBdsHh9HkskQAcNddVPvnDq37yejU8A0SR-9j45kDx6I5YdkctAkGHOFVQ_U7yXBSGEhbW9x0yam6WOw45fJc0iE4j0VMj3C9a2MaiHy0/s1600/DALL%C2%B7E%202024-12-21%2004.35.08%20-%20A%20vibrant%20and%20professional%20landscape%20thumbnail%20image%20for%20a%20blog%20post%20titled%20%27Alreflections%20Startup%20Support.%27%20The%20design%20features%20a%20modern%20and%20dynamic%20.webp', NULL, '2026-04-13 14:01:25', '2026-04-13 14:01:25', '2026-04-13 14:01:25');

CREATE TABLE IF NOT EXISTS users (
  id int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  name varchar(120) NOT NULL,
  email varchar(190) NOT NULL,
  password_hash varchar(255) NOT NULL,
  role varchar(30) NOT NULL DEFAULT 'admin',
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users (id, name, email, password_hash, role, created_at, updated_at) VALUES
(1, 'Mihigo ER Anaja', 'eranajam123@gmail.com', '$2y$10$vnPiCoKSTzLOnn.x92KrYO7lRdbNiSkcICKy379GqxZ0iJTISNwBS', 'admin', '2026-04-13 13:11:21', '2026-04-13 13:11:21');


ALTER TABLE opportunities
  ADD CONSTRAINT fk_opportunities_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
