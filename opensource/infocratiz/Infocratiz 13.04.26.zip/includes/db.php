<?php

require_once __DIR__ . '/../config.php';

function db_connect()
{
    static $connection = null;

    if ($connection instanceof mysqli) {
        return $connection;
    }

    $connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if (!$connection) {
        http_response_code(500);
        exit('Database connection failed.');
    }

    mysqli_set_charset($connection, 'utf8mb4');

    return $connection;
}
