<?php

require_once __DIR__ . '/includes/helpers.php';

$slug = isset($_GET['slug']) ? trim((string) $_GET['slug']) : '';
$category = get_category_by_slug($slug);

if (!$category) {
    http_response_code(404);
    exit('Category not found.');
}

$search = current_search_term();
$page = current_page_number();
$total = get_total_opportunities((int) $category['id'], $search);
$totalPages = max(1, (int) ceil($total / OFFERS_PER_PAGE));
$page = min($page, $totalPages);
$offset = ($page - 1) * OFFERS_PER_PAGE;
$items = get_opportunities((int) $category['id'], $search, OFFERS_PER_PAGE, $offset);
$isSearchPage = $search !== '';
$isPaginatedPage = $page > 1;
$baseCategoryUrl = absolute_url('category.php') . '?slug=' . urlencode($category['slug']);
$currentCategoryUrl = absolute_url('category.php') . '?' . http_build_query(array_filter([
    'slug' => $category['slug'],
    'search' => $search !== '' ? $search : null,
    'page' => $page > 1 ? $page : null,
]));
$pageTitle = $isSearchPage
    ? $category['name'] . ' search results for "' . $search . '" | ' . SITE_NAME
    : $category['name'] . ' Opportunities | ' . SITE_NAME;
$metaDescription = $isSearchPage
    ? seo_text('Search ' . $category['name'] . ' opportunities, offers and links on ' . SITE_NAME . ' for ' . $search . '.')
    : seo_text(($category['description'] ?: 'Browse curated opportunities in this category.') . ' Discover active links, offers and opportunities in ' . $category['name'] . '.');
$metaRobots = ($isSearchPage || $isPaginatedPage) ? 'noindex,follow' : 'index,follow';
$canonicalUrl = $isSearchPage ? $baseCategoryUrl : $currentCategoryUrl;
$socialImage = absolute_url('assets/default-thumb.svg');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle); ?></title>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <meta name="robots" content="<?php echo e($metaRobots); ?>">
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?php echo e(SITE_NAME); ?>">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($metaDescription); ?>">
    <meta property="og:url" content="<?php echo e($currentCategoryUrl); ?>">
    <meta property="og:image" content="<?php echo e($socialImage); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($metaDescription); ?>">
    <meta name="twitter:image" content="<?php echo e($socialImage); ?>">
    <link rel="stylesheet" href="<?php echo e(app_url('assets/styles.css')); ?>">
</head>
<body>
    <header class="sub-hero">
        <div class="container narrow">
            <a class="back-link" href="<?php echo e(app_url('/')); ?>">Back to home</a>
            <h1><?php echo e($category['name']); ?></h1>
            <p><?php echo e($category['description']); ?></p>
            <form class="search-card compact" method="get" action="<?php echo e(app_url('category.php')); ?>">
                <input type="hidden" name="slug" value="<?php echo e($category['slug']); ?>">
                <label for="search">Search in this category</label>
                <div class="search-row">
                    <input id="search" type="search" name="search" placeholder="Search by title or description" value="<?php echo e($search); ?>">
                    <button type="submit">Search</button>
                </div>
            </form>
        </div>
    </header>

    <main class="container page-gap">
        <?php if (empty($items)): ?>
            <section class="empty-state">
                <h2>No links found</h2>
                <p>There are no active opportunities in this category yet.</p>
            </section>
        <?php else: ?>
            <section class="grid offers-grid">
                <?php foreach ($items as $item): ?>
                    <article class="offer-card">
                        <img src="<?php echo e($item['thumbnail'] ?: DEFAULT_THUMBNAIL); ?>" alt="<?php echo e($item['title']); ?>">
                        <div class="offer-body">
                            <span class="badge"><?php echo e($category['name']); ?></span>
                            <h3><?php echo e(explode("-",$item['title'])[0]); ?></h3>
                            <p><?php echo e($item['description']); ?></p>
                        </div>
                        <a class="card-link" href="<?php echo e($item['url']); ?>" target="_blank" rel="noopener noreferrer">Open link</a>
                    </article>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <nav class="pagination">
            <?php if ($page > 1): ?>
                <a class="page-btn" href="<?php echo e(page_url(app_url('category.php'), ['slug' => $category['slug'], 'search' => $search, 'page' => $page - 1])); ?>">Previous</a>
            <?php else: ?>
                <span class="page-btn disabled">Previous</span>
            <?php endif; ?>

            <span class="page-count">Page <?php echo e($page); ?> of <?php echo e($totalPages); ?></span>

            <?php if ($page < $totalPages): ?>
                <a class="page-btn" href="<?php echo e(page_url(app_url('category.php'), ['slug' => $category['slug'], 'search' => $search, 'page' => $page + 1])); ?>">Next</a>
            <?php else: ?>
                <span class="page-btn disabled">Next</span>
            <?php endif; ?>
        </nav>
    </main>

    <script src="<?php echo e(app_url('assets/app.js')); ?>"></script>
</body>
</html>
