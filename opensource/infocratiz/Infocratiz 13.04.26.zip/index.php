<?php

require_once __DIR__ . '/includes/helpers.php';

refresh_random_stale_opportunity();

$search = current_search_term();
$sections = get_home_sections($search);
$categories = get_categories();
$isSearchPage = $search !== '';
$pageTitle = $isSearchPage
    ? 'Search results for "' . $search . '" | ' . SITE_NAME
    : SITE_NAME . ' | Freebies, Jobs, Scholarships and Bonuses';
$metaDescription = $isSearchPage
    ? seo_text('Search curated opportunity links for ' . $search . ' including affiliate offers, jobs, scholarships, bonuses and more.')
    : 'Discover freebies, jobs, scholarships, bonuses and curated opportunity offers in clean categories with fast search and regularly refreshed previews.';
$metaRobots = $isSearchPage ? 'noindex,follow' : 'index,follow';
$canonicalUrl = $isSearchPage ? absolute_url('/') : absolute_url('/');
$socialImage = absolute_url('assets/default-thumb.svg');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($pageTitle); ?></title>
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    <meta name="robots" content="<?php echo e($metaRobots); ?>">
    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?php echo e(SITE_NAME); ?>">
    <meta property="og:title" content="<?php echo e($pageTitle); ?>">
    <meta property="og:description" content="<?php echo e($metaDescription); ?>">
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>">
    <meta property="og:image" content="<?php echo e($socialImage); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo e($metaDescription); ?>">
    <meta name="twitter:image" content="<?php echo e($socialImage); ?>">
    <link rel="stylesheet" href="<?php echo e(app_url('assets/styles.css')); ?>">
</head>
<body>
    <header class="hero">
        <div class="container">
            <div class="hero-copy">
                <span class="eyebrow">Curated opportunities</span>
                <h1>Find freebies, jobs, scholarships, bonuses and more.</h1>
                <p>Browse cleanly organized links, search fast, and jump straight into the category that matters most to you.</p>
            </div>
            <form class="search-card" method="get" action="<?php echo e(app_url('/')); ?>">
                <label for="search">Search opportunities</label>
                <div class="search-row">
                    <input id="search" type="search" name="search" placeholder="Search by title or description" value="<?php echo e($search); ?>">
                    <button type="submit">Search</button>
                </div>
            </form>
        </div>
    </header>

    <main class="container page-gap">
        <section class="category-pills">
            <a class="pill active" href="<?php echo e(app_url('/')); ?>">All categories</a>
            <?php foreach ($categories as $category): ?>
                <a class="pill" href="<?php echo e(page_url(app_url('category.php'), ['slug' => $category['slug']])); ?>"><?php echo e($category['name']); ?></a>
            <?php endforeach; ?>
        </section>

        <?php if (empty($sections)): ?>
            <section class="empty-state">
                <h2>No opportunities found</h2>
                <p>Try a different search term or add new opportunities from the dashboard.</p>
            </section>
        <?php endif; ?>

        <?php foreach ($sections as $section): ?>
            <section class="category-section">
                <div class="section-heading">
                    <div>
                        <h2><?php echo e($section['category']['name']); ?></h2>
                        <p><?php echo e($section['category']['description']); ?></p>
                    </div>
                    <a class="section-link" href="<?php echo e(page_url(app_url('category.php'), ['slug' => $section['category']['slug']])); ?>">View category</a>
                </div>

                <div class="grid offers-grid">
                    <?php foreach ($section['items'] as $item): ?>
                        <article class="offer-card">
                            <img src="<?php echo e($item['thumbnail'] ?: DEFAULT_THUMBNAIL); ?>" alt="<?php echo e($item['title']); ?>">
                            <div class="offer-body">
                                <span class="badge"><?php echo e($section['category']['name']); ?></span>
                                <h3><?php echo e(explode("-",$item['title'])[0]); ?></h3>
                                <p><?php echo e($item['description']); ?></p>
                            </div>
                            <a class="card-link" href="<?php echo e($item['url']); ?>" target="_blank" rel="noopener noreferrer">Open link</a>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endforeach; ?>
    </main>

    <script src="<?php echo e(app_url('assets/app.js')); ?>"></script>
</body>
</html>