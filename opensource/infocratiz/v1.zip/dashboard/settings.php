<?php

require_once __DIR__ . '/../includes/helpers.php';

require_admin_auth();

$user = current_user();
// $categories = get_categories();
// $opportunities = get_dashboard_opportunities();
// $topCategory = get_category_with_most_links();
// $preferredCategoryId = $topCategory ? (int) $topCategory['id'] : 0;
$flash = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
if ($_SERVER["REQUEST_METHOD"]=="POST") {
	$config['sys']['custom_header']=base64_encode($_POST['custom_header']??base64_decode($config['sys']['custom_header']));
	$config['sys']['custom_footer']=base64_encode($_POST['custom_footer']??base64_decode($config['sys']['custom_footer']));
	write_ini_file($config, '../config.ini');
	$flash="Custom Codes Saved.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Links | <?php echo e(SITE_NAME); ?></title>
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="<?php echo e(app_url('assets/styles.css')); ?>">
</head>
<body class="dashboard-body">
    <main class="container dashboard-layout">
        <aside class="dashboard-aside">
            <h1>Links</h1>
            <p>Add single or bulk opportunity URLs and review saved previews.</p>
            <p>Signed in as <?php echo e($user['name']); ?>.</p>
            <a class="section-link" href="<?php echo e(app_url('dashboard/')); ?>">Back to dashboard</a><br><br>
            <a class="section-link" href="<?php echo e(app_url('dashboard/categories.php')); ?>">Manage categories</a><br><br>
            <a class="section-link" href="<?php echo e(app_url('dashboard/links.php')); ?>">Manage links</a>
        </aside>

        <section class="dashboard-main">
            <?php if ($flash !== ''): ?>
                <div class="flash"><?php echo e($flash); ?></div>
            <?php endif; ?>

            <div class="dashboard-grid">
                <section class="panel">
                    <h2>Custom Header</h2>
                    <form method="post">
                        <label>HTML Codes Here</label>
                        <textarea name="custom_header" rows="10" placeholder="<my_codes>&#10;	Go Here . . .&#10;</my_codes>" required><?=base64_decode($config['sys']['custom_header'])?></textarea>
                        <button type="submit">Save Changes</button>
                    </form>
                </section>
				<section class="panel">
                    <h2>Custom Footer</h2>
                    <form method="post">
                        <label>HTML Codes Here</label>
                        <textarea name="custom_footer" rows="10" placeholder="<my_codes>&#10;	Go Here . . .&#10;</my_codes>" required><?=base64_decode($config['sys']['custom_footer'])?></textarea>
                        <button type="submit">Save Changes</button>
                    </form>
                </section>
            </div>
        </section>
    </main>

    <script src="<?php echo e(app_url('assets/app.js')); ?>"></script>
</body>
</html>
