<?php

require_once __DIR__ . '/../includes/helpers.php';

require_admin_auth();

$user = current_user();
$stats = get_dashboard_stats();
$topCategory = get_category_with_most_links();
$flash = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | <?php echo e(SITE_NAME); ?></title>
    <meta name="robots" content="noindex,nofollow">
    <link rel="stylesheet" href="<?php echo e(app_url('assets/styles.css')); ?>">
</head>
<body class="dashboard-body">
    <main class="container dashboard-layout">
        <aside class="dashboard-aside">
            <h1>Dashboard</h1>
            <p>Choose the workspace you want and manage one task at a time.</p>
            <p>Signed in as <?php echo e($user['name']); ?>.</p>
            <a class="section-link" href="<?php echo e(app_url('/')); ?>">Open website</a><br><br>
            <a class="section-link" href="<?php echo e(app_url('dashboard/settings.php')); ?>">Settings</a><br><br>
            <a class="section-link" href="<?php echo e(app_url('dashboard/logout.php')); ?>">Logout</a>
        </aside>

        <section class="dashboard-main">
            <?php if ($flash !== ''): ?>
                <div class="flash"><?php echo e($flash); ?></div>
            <?php endif; ?>

            <section class="dashboard-grid">
                <article class="panel stat-card">
                    <h2><?php echo e($stats['categories']); ?></h2>
                    <p>Categories</p>
                </article>
                <article class="panel stat-card">
                    <h2><?php echo e($stats['opportunities']); ?></h2>
                    <p>Saved links</p>
                </article>
            </section>

            <section class="dashboard-grid">
                <article class="panel">
                    <h2>Manage categories</h2>
                    <p>Create, edit and remove categories from a dedicated page.</p>
                    <a class="section-link" href="<?php echo e(app_url('dashboard/categories.php')); ?>">Open categories</a>
                </article>

                <article class="panel">
                    <h2>Manage links</h2>
                    <p>Add one link or many at once, then remove outdated items any time.</p>
                    <?php if ($topCategory): ?>
                        <p>Default category suggestion: <?php echo e($topCategory['name']); ?>.</p>
                    <?php endif; ?>
                    <a class="section-link" href="<?php echo e(app_url('dashboard/links.php')); ?>">Open links</a>
                </article>
            </section>
        </section>
    </main>
</body>
</html>
