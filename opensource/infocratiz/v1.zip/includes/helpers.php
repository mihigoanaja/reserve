<?php

require_once __DIR__ . '/db.php';

date_default_timezone_set('Africa/Tripoli');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect_to($path)
{
    header('Location: ' . app_url($path));
    exit;
}

function app_url($path = '')
{
    if ($path === '' || $path === '/') {
        return APP_BASE_PATH !== '' ? APP_BASE_PATH . '/' : '/';
    }

    return APP_BASE_PATH . '/' . ltrim($path, '/');
}

function request_scheme()
{
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    return $https ? 'https' : 'http';
}

function site_origin()
{
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    return request_scheme() . '://' . $host;
}

function absolute_url($path = '')
{
    return site_origin() . app_url($path);
}

function seo_text($text, $limit = 160)
{
    $text = trim(preg_replace('/\s+/', ' ', strip_tags((string) $text)));

    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        return mb_strlen($text) > $limit ? rtrim(mb_substr($text, 0, $limit - 3)) . '...' : $text;
    }

    return strlen($text) > $limit ? rtrim(substr($text, 0, $limit - 3)) . '...' : $text;
}

function current_search_term()
{
    return isset($_GET['search']) ? trim((string) $_GET['search']) : '';
}

function current_page_number()
{
    $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
    return max(1, $page);
}

function users_exist()
{
    $db = db_connect();
    $result = mysqli_query($db, "SELECT COUNT(*) AS total FROM users");
    $row = $result ? mysqli_fetch_assoc($result) : ['total' => 0];
    return (int) $row['total'] > 0;
}

function current_user()
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $db = db_connect();
    $id = (int) $_SESSION['user_id'];
    $stmt = mysqli_prepare($db, "SELECT id, name, email, role FROM users WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    return $user;
}

function is_logged_in()
{
    return current_user() !== null;
}

function require_admin_auth()
{
    if (!is_logged_in()) {
        redirect_to('dashboard/login.php');
    }
}

function create_initial_admin($name, $email, $password)
{
    if (users_exist()) {
        return ['ok' => false, 'error' => 'Registration is closed.'];
    }

    $db = db_connect();
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $role = 'admin';
    $stmt = mysqli_prepare($db, "INSERT INTO users (name, email, password_hash, role, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())");
    mysqli_stmt_bind_param($stmt, 'ssss', $name, $email, $hash, $role);
    $ok = mysqli_stmt_execute($stmt);
    $userId = mysqli_insert_id($db);
    mysqli_stmt_close($stmt);

    if (!$ok) {
        return ['ok' => false, 'error' => 'The admin account could not be created.'];
    }

    $_SESSION['user_id'] = $userId;
    return ['ok' => true];
}

function authenticate_user($email, $password)
{
    $db = db_connect();
    $stmt = mysqli_prepare($db, "SELECT id, password_hash FROM users WHERE email = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    if (!$user || !password_verify($password, $user['password_hash'])) {
        return ['ok' => false, 'error' => 'Invalid email or password.'];
    }

    $_SESSION['user_id'] = (int) $user['id'];
    return ['ok' => true];
}

function logout_user()
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }

    session_destroy();
}

function get_categories()
{
    $db = db_connect();
    $sql = "SELECT id, name, slug, description FROM categories ORDER BY name ASC";
    $result = mysqli_query($db, $sql);
    $categories = [];

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $categories[] = $row;
        }
    }

    return $categories;
}

function get_category_with_most_links()
{
    $db = db_connect();
    $sql = "SELECT categories.id, categories.name, COUNT(opportunities.id) AS total_links
            FROM categories
            LEFT JOIN opportunities ON opportunities.category_id = categories.id
            GROUP BY categories.id, categories.name
            ORDER BY total_links DESC, categories.name ASC
            LIMIT 1";
    $result = mysqli_query($db, $sql);
    return $result ? mysqli_fetch_assoc($result) : null;
}

function get_category_by_slug($slug)
{
    $db = db_connect();
    $sql = "SELECT id, name, slug, description FROM categories WHERE slug = ? LIMIT 1";
    $stmt = mysqli_prepare($db, $sql);
    mysqli_stmt_bind_param($stmt, 's', $slug);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $category = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    return $category;
}

function slugify($text)
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');
    return $text !== '' ? $text : 'category-' . time();
}

function ensure_unique_category_slug($name, $ignoreId = null)
{
    $db = db_connect();
    $base = slugify($name);
    $slug = $base;
    $counter = 1;

    while (true) {
        if ($ignoreId) {
            $sql = "SELECT id FROM categories WHERE slug = ? AND id != ? LIMIT 1";
            $stmt = mysqli_prepare($db, $sql);
            mysqli_stmt_bind_param($stmt, 'si', $slug, $ignoreId);
        } else {
            $sql = "SELECT id FROM categories WHERE slug = ? LIMIT 1";
            $stmt = mysqli_prepare($db, $sql);
            mysqli_stmt_bind_param($stmt, 's', $slug);
        }

        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $exists = $result && mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if (!$exists) {
            return $slug;
        }

        $counter++;
        $slug = $base . '-' . $counter;
    }
}

function opportunity_where_clause($categoryId = null, $search = '')
{
    $parts = ["(expires_at IS NULL OR expires_at >= CURDATE())"];
    $types = '';
    $params = [];

    if ($categoryId !== null) {
        $parts[] = "category_id = ?";
        $types .= 'i';
        $params[] = $categoryId;
    }

    if ($search !== '') {
        $parts[] = "(opportunities.title LIKE ? OR opportunities.description LIKE ?)";
        $types .= 'ss';
        $like = '%' . $search . '%';
        $params[] = $like;
        $params[] = $like;
    }

    return [
        'sql' => ' WHERE ' . implode(' AND ', $parts),
        'types' => $types,
        'params' => $params,
    ];
}

function bind_stmt_params($stmt, $types, $params)
{
    if ($types === '') {
        return;
    }

    $refs = [$stmt, $types];

    foreach ($params as $index => $value) {
        $params[$index] = $value;
        $refs[] = &$params[$index];
    }

    call_user_func_array('mysqli_stmt_bind_param', $refs);
}

function get_total_opportunities($categoryId = null, $search = '')
{
    $db = db_connect();
    $where = opportunity_where_clause($categoryId, $search);
    $sql = "SELECT COUNT(*) AS total FROM opportunities" . $where['sql'];
    $stmt = mysqli_prepare($db, $sql);
    bind_stmt_params($stmt, $where['types'], $where['params']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : ['total' => 0];
    mysqli_stmt_close($stmt);

    return (int) $row['total'];
}

function get_opportunities($categoryId = null, $search = '', $limit = OFFERS_PER_PAGE, $offset = 0)
{
    $db = db_connect();
    $where = opportunity_where_clause($categoryId, $search);
    $sql = "SELECT opportunities.*, categories.name AS category_name, categories.slug AS category_slug
            FROM opportunities
            INNER JOIN categories ON categories.id = opportunities.category_id"
            . $where['sql'] .
            " ORDER BY opportunities.created_at DESC LIMIT ? OFFSET ?";

    $stmt = mysqli_prepare($db, $sql);
    $types = $where['types'] . 'ii';
    $params = array_merge($where['params'], [$limit, $offset]);
    bind_stmt_params($stmt, $types, $params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $items = [];

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $items[] = $row;
        }
    }

    mysqli_stmt_close($stmt);

    return $items;
}

function get_home_sections($search = '')
{
    $categories = get_categories();
    $sections = [];

    foreach ($categories as $category) {
        $items = get_opportunities((int) $category['id'], $search, HOME_CATEGORY_LIMIT, 0);
        if (!empty($items)) {
            $sections[] = [
                'category' => $category,
                'items' => $items,
            ];
        }
    }

    return $sections;
}

function page_url($path, $params = [])
{
    $query = http_build_query(array_filter($params, function ($value) {
        return $value !== null && $value !== '';
    }));

    return $query === '' ? $path : $path . '?' . $query;
}

function preview_target_url($url)
{
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return ['ok' => false, 'error' => 'Please provide a valid URL.'];
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 12,
            'follow_location' => 1,
            'user_agent' => 'InfocratizBot/1.0',
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
        ],
    ]);

    $html = @file_get_contents($url, false, $context);
    $responseLine = isset($http_response_header[0]) ? $http_response_header[0] : '';

    if ($html === false || trim($html) === '' || preg_match('/\s(4|5)\d{2}\s/', $responseLine)) {
        return ['ok' => false, 'error' => 'The link could not be previewed.'];
    }

    $meta = [
        'title' => '',
        'description' => '',
        'thumbnail' => '',
    ];

    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $loaded = $dom->loadHTML($html);
    libxml_clear_errors();

    if ($loaded) {
        $xpath = new DOMXPath($dom);

        $titleNode = $xpath->query('//meta[@property="og:title"]/@content')->item(0);
        if (!$titleNode) {
            $titleNode = $xpath->query('//title')->item(0);
        }
        $meta['title'] = $titleNode ? trim($titleNode->nodeValue) : parse_url($url, PHP_URL_HOST);

        $descriptionNode = $xpath->query('//meta[@property="og:description"]/@content')->item(0);
        if (!$descriptionNode) {
            $descriptionNode = $xpath->query('//meta[@name="description"]/@content')->item(0);
        }
        $meta['description'] = $descriptionNode ? trim($descriptionNode->nodeValue) : 'Visit this opportunity to view more details.';

        $imageNode = $xpath->query('//meta[@property="og:image"]/@content')->item(0);
        $meta['thumbnail'] = $imageNode ? absolutize_url($url, trim($imageNode->nodeValue)) : '';
    }

    if ($meta['title'] === '') {
        $meta['title'] = parse_url($url, PHP_URL_HOST);
    }

    return ['ok' => true, 'data' => $meta];
}

function absolutize_url($baseUrl, $relativeUrl)
{
    if ($relativeUrl === '') {
        return '';
    }

    if (preg_match('/^https?:\/\//i', $relativeUrl)) {
        return $relativeUrl;
    }

    $parts = parse_url($baseUrl);
    if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
        return $relativeUrl;
    }

    $scheme = $parts['scheme'];
    $host = $parts['host'];
    $port = isset($parts['port']) ? ':' . $parts['port'] : '';

    if (strpos($relativeUrl, '//') === 0) {
        return $scheme . ':' . $relativeUrl;
    }

    if (strpos($relativeUrl, '/') === 0) {
        return $scheme . '://' . $host . $port . $relativeUrl;
    }

    $path = isset($parts['path']) ? dirname($parts['path']) : '';
    $path = trim(str_replace('\\', '/', $path), '/');

    return $scheme . '://' . $host . $port . '/' . ($path !== '.' && $path !== '' ? $path . '/' : '') . ltrim($relativeUrl, '/');
}

function create_opportunity($categoryId, $url, $expiresAt = null)
{
    $preview = preview_target_url($url);

    if (!$preview['ok']) {
        return $preview;
    }

    $db = db_connect();
    $data = $preview['data'];
    $sql = "INSERT INTO opportunities
            (category_id, url, title, description, thumbnail, expires_at, last_previewed_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), NOW())";
    $stmt = mysqli_prepare($db, $sql);
    mysqli_stmt_bind_param(
        $stmt,
        'isssss',
        $categoryId,
        $url,
        $data['title'],
        $data['description'],
        $data['thumbnail'],
        $expiresAt
    );

    $saved = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    if (!$saved) {
        return ['ok' => false, 'error' => 'The opportunity could not be saved.'];
    }

    return ['ok' => true];
}

function create_opportunities_bulk($categoryId, $urlsText, $expiresAt = null)
{
    $urls = preg_split('/\r\n|\r|\n/', $urlsText);
    $urls = array_values(array_unique(array_filter(array_map('trim', $urls))));

    $summary = [
        'saved' => 0,
        'failed' => 0,
        'errors' => [],
    ];

    foreach ($urls as $url) {
        $result = create_opportunity($categoryId, $url, $expiresAt);
        if ($result['ok']) {
            $summary['saved']++;
            continue;
        }

        $summary['failed']++;
        $summary['errors'][] = $url . ': ' . $result['error'];
    }

    return $summary;
}

function refresh_random_stale_opportunity()
{
    if (random_int(1, 100) > STALE_REFRESH_CHANCE) {
        return;
    }

    $db = db_connect();
    $sql = "SELECT id, url FROM opportunities
            WHERE last_previewed_at IS NULL
               OR last_previewed_at <= DATE_SUB(NOW(), INTERVAL ? DAY)
            ORDER BY RAND()
            LIMIT 1";
    $stmt = mysqli_prepare($db, $sql);
    $days = STALE_DAYS;
    mysqli_stmt_bind_param($stmt, 'i', $days);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $item = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    if (!$item) {
        return;
    }

    $preview = preview_target_url($item['url']);

    if (!$preview['ok']) {
        $delete = mysqli_prepare($db, "DELETE FROM opportunities WHERE id = ?");
        mysqli_stmt_bind_param($delete, 'i', $item['id']);
        mysqli_stmt_execute($delete);
        mysqli_stmt_close($delete);
        return;
    }

    $data = $preview['data'];
    $update = mysqli_prepare(
        $db,
        "UPDATE opportunities
         SET title = ?, description = ?, thumbnail = ?, last_previewed_at = NOW(), updated_at = NOW()
         WHERE id = ?"
    );
    mysqli_stmt_bind_param($update, 'sssi', $data['title'], $data['description'], $data['thumbnail'], $item['id']);
    mysqli_stmt_execute($update);
    mysqli_stmt_close($update);
}

function delete_opportunity($id)
{
    $db = db_connect();
    $stmt = mysqli_prepare($db, "DELETE FROM opportunities WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function create_category($name, $description)
{
    $db = db_connect();
    $slug = ensure_unique_category_slug($name);
    $stmt = mysqli_prepare($db, "INSERT INTO categories (name, slug, description, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
    mysqli_stmt_bind_param($stmt, 'sss', $name, $slug, $description);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

function update_category($id, $name, $description)
{
    $db = db_connect();
    $slug = ensure_unique_category_slug($name, $id);
    $stmt = mysqli_prepare($db, "UPDATE categories SET name = ?, slug = ?, description = ?, updated_at = NOW() WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'sssi', $name, $slug, $description, $id);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

function delete_category($id)
{
    $db = db_connect();

    $deleteOpportunities = mysqli_prepare($db, "DELETE FROM opportunities WHERE category_id = ?");
    mysqli_stmt_bind_param($deleteOpportunities, 'i', $id);
    mysqli_stmt_execute($deleteOpportunities);
    mysqli_stmt_close($deleteOpportunities);

    $deleteCategory = mysqli_prepare($db, "DELETE FROM categories WHERE id = ?");
    mysqli_stmt_bind_param($deleteCategory, 'i', $id);
    mysqli_stmt_execute($deleteCategory);
    mysqli_stmt_close($deleteCategory);
}

function get_dashboard_opportunities()
{
    $db = db_connect();
    $sql = "SELECT opportunities.*, categories.name AS category_name
            FROM opportunities
            INNER JOIN categories ON categories.id = opportunities.category_id
            ORDER BY opportunities.created_at DESC";
    $result = mysqli_query($db, $sql);
    $items = [];

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $items[] = $row;
        }
    }

    return $items;
}

function get_dashboard_stats()
{
    $db = db_connect();
    $totals = [
        'categories' => 0,
        'opportunities' => 0,
    ];

    $categoryResult = mysqli_query($db, "SELECT COUNT(*) AS total FROM categories");
    $opportunityResult = mysqli_query($db, "SELECT COUNT(*) AS total FROM opportunities");

    if ($categoryResult) {
        $row = mysqli_fetch_assoc($categoryResult);
        $totals['categories'] = (int) $row['total'];
    }

    if ($opportunityResult) {
        $row = mysqli_fetch_assoc($opportunityResult);
        $totals['opportunities'] = (int) $row['total'];
    }

    return $totals;
}

function write_ini_file($array, $file) {
    $content = "";

    foreach ($array as $key => $value) {
        if (is_array($value)) {
            $content .= "[$key]\n";
            foreach ($value as $k => $v) {
                $content .= "$k=$v\n";
            }
        } else {
            $content .= "$key=$value\n";
        }
        $content .= "\n";
    }

    file_put_contents($file, $content);
}