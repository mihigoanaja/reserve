<?php
function save_ini_file($array, $file) {
    $content = "";

    foreach ($array as $key => $value) {
        if (is_array($value)) {
            $content .= "[$key]\n";
            foreach ($value as $k => $v) {
                $content .= "$k=$v\n";
            }
        } else {
            $content .= "$key=$value\n";
        }
        $content .= "\n";
    }

    file_put_contents($file, $content);
}
$config=parse_ini_file("config.ini",true);
if (file_exists("../config.ini")) {
	$sys_config=parse_ini_file("../config.ini",true);
} elseif (file_exists("../../config.ini")) {
	$sys_config=parse_ini_file("../../config.ini",true);
}
if (isset($sys_config)) {
	$config['db']['host']=$sys_config['database']['host']??$config['db']['host'];
	$config['db']['user']=$sys_config['database']['user']??$config['db']['user'];
	$config['db']['password']=$sys_config['database']['pass']??$config['db']['password'];
	$config['db']['name']=$sys_config['database']['name']??$config['db']['name'];
	
	$config['SITE_NAME']=$sys_config['system']['name']??$config['SITE_NAME'];
    if (file_exists("config.ini")) {
    	save_ini_file($config,'config.ini');
    }
    
}
define('DB_HOST', $config['db']['host']);
define('DB_USER', $config['db']['user']);
define('DB_PASS', $config['db']['password']);
define('DB_NAME', $config['db']['name']);

$documentRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : null;
$projectRoot = realpath(__DIR__);
$basePath = '';

if ($documentRoot && $projectRoot) {
    $documentRoot = str_replace('\\', '/', $documentRoot);
    $projectRoot = str_replace('\\', '/', $projectRoot);

    if (strpos($projectRoot, $documentRoot) === 0) {
        $basePath = substr($projectRoot, strlen($documentRoot));
    }
}

$basePath = trim(str_replace('\\', '/', $basePath), '/');

define('SITE_NAME', $config['SITE_NAME']);
define('APP_BASE_PATH', $basePath !== '' ? '/' . $basePath : '');
define('DEFAULT_THUMBNAIL', APP_BASE_PATH . '/'. $config['DEFAULT_THUMBNAIL']);
define('OFFERS_PER_PAGE', $config['OFFERS_PER_PAGE']);
define('HOME_CATEGORY_LIMIT', $config['HOME_CATEGORY_LIMIT']);
define('STALE_DAYS', $config['STALE_DAYS']);
define('STALE_REFRESH_CHANCE', $config['STALE_REFRESH_CHANCE']);
