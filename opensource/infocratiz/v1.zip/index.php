<?php

require_once __DIR__ . '/includes/helpers.php';

refresh_random_stale_opportunity();

$search = current_search_term();
$sections = get_home_sections($search);
$categories = get_categories();
$isSearchPage = $search !== '';
$pageTitle = $isSearchPage
    ? 'Search results for "' . $search . '" | ' . SITE_NAME
    : SITE_NAME . ' | '.$config['info']['tagline'];
$metaDescription = $isSearchPage
    ? seo_text('Search results for ' . $search . ' | '.$config['info']['tagline'])
    : $config['info']['description'];
$metaRobots = $isSearchPage ? 'noindex,follow' : 'index,follow';
$canonicalUrl = $isSearchPage ? absolute_url('/') : absolute_url('/');
$socialImage = DEFAULT_THUMBNAIL;
?>
<!DOCTYPE html>
<html lang="en">
<?php include "includes/head.php"; ?>
<body>
    <header class="hero">
        <div class="container">
            <div class="hero-copy">
                <span class="eyebrow"><?=SITE_NAME;?></span>
                <h1><?=$config['info']['tagline'];?></h1>
                <p>Browse cleanly organized links, search fast, and jump straight into the category that matters most to you.</p>
            </div>
            <form class="search-card" method="get" action="<?php echo e(app_url('/')); ?>">
                <label for="search">Search opportunities</label>
                <div class="search-row">
                    <input id="search" type="search" name="search" placeholder="Search by title or description" value="<?php echo e($search); ?>">
                    <button type="submit">Search</button>
                </div>
            </form>
        </div>
    </header>

    <main class="container page-gap">
        <section class="category-pills">
            <a class="pill active" href="<?php echo e(app_url('/')); ?>">All categories</a>
            <?php foreach ($categories as $category): ?>
                <a class="pill" href="<?php echo e(page_url(app_url('category.php'), ['slug' => $category['slug']])); ?>"><?php echo e($category['name']); ?></a>
            <?php endforeach; ?>
        </section>

        <?php if (empty($sections)): ?>
            <section class="empty-state">
                <h2>No opportunities found</h2>
                <p>Try a different search term or add new opportunities from the dashboard.</p>
            </section>
        <?php endif; ?>

        <?php foreach ($sections as $section): ?>
            <section class="category-section">
                <div class="section-heading">
                    <div>
                        <h2><?php echo e($section['category']['name']); ?></h2>
                        <p><?php echo e($section['category']['description']); ?></p>
                    </div>
                    <a class="section-link" href="<?php echo e(page_url(app_url('category.php'), ['slug' => $section['category']['slug']])); ?>">View category</a>
                </div>

                <div class="grid offers-grid">
                    <?php foreach ($section['items'] as $item): ?>
                        <article class="offer-card">
                            <img src="<?php echo e($item['thumbnail'] ?: DEFAULT_THUMBNAIL); ?>" alt="<?php echo e($item['title']); ?>">
                            <div class="offer-body">
                                <span class="badge"><?php echo e($section['category']['name']); ?></span>
                                <h3><?php echo e(explode("-",$item['title'])[0]); ?></h3>
                                <p><?php echo e($item['description']); ?></p>
                            </div>
                            <a class="card-link" href="<?php echo e($item['url']); ?>" target="_blank" rel="noopener noreferrer">Open link</a>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endforeach; ?>
    </main>
    <script src="<?php echo e(app_url('assets/app.js')); ?>"></script>
	<?=base64_decode($config['sys']['custom_footer'])?>
</body>
</html>